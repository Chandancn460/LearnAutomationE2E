# Learn Automation — Selenium Java TestNG Project

## Project Structure

```
LearnAutomation/
├── pom.xml                                          # Maven dependencies & build config
├── src/
│   ├── main/java/com/learnautomation/
│   │   ├── config/
│   │   │   ├── Constants.java                       # All static values (URL, credentials, paths)
│   │   │   └── TestConfig.java                      # Runtime config (browser param / sys prop)
│   │   ├── factory/
│   │   │   ├── BrowserFactory.java                  # Creates WebDriver per browser
│   │   │   └── DriverFactory.java                   # ThreadLocal driver management
│   │   ├── pages/
│   │   │   ├── BasePage.java                        # Reusable Selenium actions (click, type...)
│   │   │   ├── LoginPage.java                       # Login page POM
│   │   │   ├── DashboardPage.java                   # Dashboard/nav POM
│   │   │   └── ManageCoursesPage.java               # Manage Courses page POM
│   │   └── utils/
│   │       ├── ExtentReportManager.java             # HTML report lifecycle
│   │       ├── ScreenshotUtil.java                  # Screenshot capture & embed
│   │       └── WaitUtil.java                        # Explicit wait helpers
│   └── test/
│       ├── java/com/learnautomation/tests/
│       │   ├── BaseTest.java                        # @BeforeSuite/@AfterSuite/@BeforeMethod
│       │   └── CourseManagementTest.java            # 5 test cases (TC_001–TC_005)
│       └── resources/
│           ├── testng.xml                           # TestNG suite configuration
│           └── log4j2.xml                           # Logging configuration
```

## Prerequisites

| Tool | Version |
|------|---------|
| Java JDK | 11 or higher |
| Maven | 3.6+ |
| Chrome | Latest (WebDriverManager auto-downloads driver) |

## Setup Steps

1. **Clone / extract the project** to `D:\Mukeshdata\LearnAutomation`
2. **Add a sample image** at `D:\Mukeshdata\sample.png` (used in TC_003 file upload)
3. **Create output folders** (Maven will use these):
   ```
   D:\Mukeshdata\reports\
   D:\Mukeshdata\logs\
   D:\Mukeshdata\screenshots\
   ```
4. **Open in IntelliJ IDEA / Eclipse** and import as a Maven project.

## Running the Tests

### Via Maven (command line)
```bash
# Default Chrome
mvn clean test

# Override browser
mvn clean test -Dbrowser=firefox
mvn clean test -Dbrowser=edge
```

### Via IDE
- Right-click `testng.xml` → **Run As → TestNG Suite**
- Or right-click `CourseManagementTest.java` → **Run As → TestNG Test**

## Test Cases

| TC ID | Name | Description |
|-------|------|-------------|
| TC_001 | VerifyLogin | Login with valid admin credentials |
| TC_002 | VerifyEmptyFormValidation | Verify "Please fill all the fields" message |
| TC_003 | AddNewCourse | Add course with all details, verify active |
| TC_004 | DeleteCourse | Delete added course, verify removal |
| TC_005 | Logout | Logout and verify redirect to login page |

## Reports

| Artifact | Location |
|----------|----------|
| HTML Report | `D:\Mukeshdata\reports\ExtentReport.html` |
| Log File | `D:\Mukeshdata\logs\automation.log` |
| Screenshots | `D:\Mukeshdata\screenshots\` |

## Configuration

Edit `Constants.java` to change:
- `APP_URL` — application URL
- `ADMIN_EMAIL` / `ADMIN_PASSWORD` — credentials
- `SAMPLE_FILE_PATH` — path to the upload file
- `COURSE_NAME`, dates, price, etc.
