package com.learnautomation.config;

/**
 * Constants.java
 * Holds all static configuration values used across the framework.
 * Centralising constants avoids hard-coding values in multiple places.
 */
public class Constants {

    // ----------------------------------------------------------------
    // Application URL
    // ----------------------------------------------------------------
    /** Base URL of the application under test */
    public static final String APP_URL = "https://freelance-learn-automation.vercel.app/login";

    // ----------------------------------------------------------------
    // Login Credentials
    // ----------------------------------------------------------------
    /** Valid admin email address */
    public static final String ADMIN_EMAIL    = "admin@email.com";
    /** Valid admin password */
    public static final String ADMIN_PASSWORD = "admin@123";

    // ----------------------------------------------------------------
    // Browser Settings
    // ----------------------------------------------------------------
    /** Default browser — can be overridden via TestConfig / testng.xml parameter */
    public static final String DEFAULT_BROWSER = "chrome";

    /** Implicit wait in seconds for WebDriver */
    public static final int IMPLICIT_WAIT_SECONDS = 10;

    /** Explicit wait timeout in seconds */
    public static final int EXPLICIT_WAIT_SECONDS = 20;

    /** Page load timeout in seconds */
    public static final int PAGE_LOAD_TIMEOUT_SECONDS = 30;

    // ----------------------------------------------------------------
    // Course Details
    // ----------------------------------------------------------------
    /** Course name to be entered during Add Course test */
    public static final String COURSE_NAME        = "My First Course";
    /** Course description */
    public static final String COURSE_DESCRIPTION = "My First Course Description";
    /** Instructor name */
    public static final String INSTRUCTOR_NAME    = "Mukesh";
    /** Course price */
    public static final String COURSE_PRICE       = "500";
    /** Course start date (DD) */
    public static final String START_DATE_DAY     = "18";
    /** Course start month */
    public static final String START_DATE_MONTH   = "April";
    /** Course start year */
    public static final String START_DATE_YEAR    = "2025";
    /** Course end date (DD) */
    public static final String END_DATE_DAY       = "19";
    /** Course end month */
    public static final String END_DATE_MONTH     = "May";
    /** Course end year */
    public static final String END_DATE_YEAR      = "2025";

    // ----------------------------------------------------------------
    // File Path for Upload
    // ----------------------------------------------------------------
    /**
     * Absolute path to the sample file used in the file-upload step.
     * Update this path to a valid file on the machine executing the tests.
     */
    public static final String SAMPLE_FILE_PATH = "D:\\Mukeshdata\\sample.png";

    // ----------------------------------------------------------------
    // Expected Messages
    // ----------------------------------------------------------------
    /** Validation message shown when Save is clicked with empty fields */
    public static final String VALIDATION_MSG_EMPTY = "Please fill all the fields";

    // ----------------------------------------------------------------
    // Report / Log / Screenshot Paths
    // ----------------------------------------------------------------
    /** Folder where ExtentReports HTML report is saved */
    public static final String REPORT_PATH      = "D:\\Mukeshdata\\reports\\ExtentReport.html";
    /** Folder where Log4j2 log files are written */
    public static final String LOG_PATH         = "D:\\Mukeshdata\\logs\\";
    /** Folder where screenshots are saved on failure */
    public static final String SCREENSHOT_PATH  = "D:\\Mukeshdata\\screenshots\\";

    // Private constructor — utility class, not meant to be instantiated
    private Constants() {}
}
