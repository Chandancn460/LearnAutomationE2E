package com.learnautomation.config;

/**
 * TestConfig.java
 * Reads runtime configuration supplied via testng.xml <parameter> tags
 * or system properties (-Dbrowser=firefox).
 * This allows the same tests to run against different browsers/environments
 * without changing source code.
 */
public class TestConfig {

    // ----------------------------------------------------------------
    // Browser selection
    // ----------------------------------------------------------------

    /**
     * Determines which browser to launch.
     * Priority order:
     *   1. System property  : -Dbrowser=chrome
     *   2. testng.xml param : <parameter name="browser" value="chrome"/>
     *   3. Fallback         : Constants.DEFAULT_BROWSER
     *
     * @param browserParam value injected from testng.xml (may be null)
     * @return browser name in lower-case, e.g. "chrome", "firefox", "edge"
     */
    public static String getBrowser(String browserParam) {
        // Check system property first (highest priority — CI / command line)
        String sysProp = System.getProperty("browser");
        if (sysProp != null && !sysProp.isBlank()) {
            return sysProp.trim().toLowerCase(); // use CLI-supplied browser
        }
        // Use testng.xml parameter if provided
        if (browserParam != null && !browserParam.isBlank()) {
            return browserParam.trim().toLowerCase();
        }
        // Default fallback
        return Constants.DEFAULT_BROWSER;
    }

    // ----------------------------------------------------------------
    // Application URL (can also be made configurable per environment)
    // ----------------------------------------------------------------

    /**
     * Returns the application URL.
     * Could be extended to support staging / production environments.
     *
     * @return URL string
     */
    public static String getAppUrl() {
        String envUrl = System.getProperty("app.url");  // allow -Dapp.url=... override
        return (envUrl != null && !envUrl.isBlank()) ? envUrl : Constants.APP_URL;
    }
}
