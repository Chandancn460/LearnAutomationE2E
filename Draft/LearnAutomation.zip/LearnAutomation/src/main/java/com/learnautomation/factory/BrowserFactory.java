package com.learnautomation.factory;

import com.learnautomation.config.Constants;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

import java.time.Duration;

/**
 * BrowserFactory.java
 * Responsible for creating and returning a configured WebDriver instance
 * for a given browser name.  WebDriverManager handles driver binaries
 * automatically — no manual chromedriver download required.
 */
public class BrowserFactory {

    // Log4j2 logger for this class
    private static final Logger log = LogManager.getLogger(BrowserFactory.class);

    /**
     * Creates and returns a WebDriver instance for the specified browser.
     *
     * @param browser  browser name: "chrome" | "firefox" | "edge"
     * @return configured WebDriver ready to use
     * @throws IllegalArgumentException if an unsupported browser name is given
     */
    public static WebDriver createDriver(String browser) {
        log.info("Creating WebDriver for browser: {}", browser); // log chosen browser

        WebDriver driver; // will hold the created driver

        switch (browser.toLowerCase()) {

            // --------------------------------------------------------
            // Google Chrome
            // --------------------------------------------------------
            case "chrome": {
                WebDriverManager.chromedriver().setup(); // auto-download chromedriver
                ChromeOptions options = new ChromeOptions();
                options.addArguments("--start-maximized");      // open maximised window
                options.addArguments("--disable-notifications"); // block browser notifications
                options.addArguments("--remote-allow-origins=*"); // allow cross-origin requests
                driver = new ChromeDriver(options);
                log.info("ChromeDriver created successfully.");
                break;
            }

            // --------------------------------------------------------
            // Mozilla Firefox
            // --------------------------------------------------------
            case "firefox": {
                WebDriverManager.firefoxdriver().setup(); // auto-download geckodriver
                FirefoxOptions options = new FirefoxOptions();
                options.addArguments("--start-maximized"); // maximise window
                driver = new FirefoxDriver(options);
                log.info("FirefoxDriver created successfully.");
                break;
            }

            // --------------------------------------------------------
            // Microsoft Edge
            // --------------------------------------------------------
            case "edge": {
                WebDriverManager.edgedriver().setup(); // auto-download edgedriver
                EdgeOptions options = new EdgeOptions();
                options.addArguments("--start-maximized");
                driver = new EdgeDriver(options);
                log.info("EdgeDriver created successfully.");
                break;
            }

            // --------------------------------------------------------
            // Unsupported browser
            // --------------------------------------------------------
            default:
                log.error("Unsupported browser requested: {}", browser);
                throw new IllegalArgumentException(
                    "Browser '" + browser + "' is not supported. Use: chrome | firefox | edge");
        }

        // ----------------------------------------------------------------
        // Apply common timeouts to every driver
        // ----------------------------------------------------------------
        // Implicit wait — WebDriver waits up to N seconds before throwing NoSuchElement
        driver.manage().timeouts()
              .implicitlyWait(Duration.ofSeconds(Constants.IMPLICIT_WAIT_SECONDS));

        // Page load timeout — how long to wait for a page to fully load
        driver.manage().timeouts()
              .pageLoadTimeout(Duration.ofSeconds(Constants.PAGE_LOAD_TIMEOUT_SECONDS));

        log.info("Timeouts configured: implicit={}s, pageLoad={}s",
                 Constants.IMPLICIT_WAIT_SECONDS, Constants.PAGE_LOAD_TIMEOUT_SECONDS);

        return driver; // return fully configured driver to caller
    }

    // Private constructor — this is a utility/factory class, not instantiated
    private BrowserFactory() {}
}
