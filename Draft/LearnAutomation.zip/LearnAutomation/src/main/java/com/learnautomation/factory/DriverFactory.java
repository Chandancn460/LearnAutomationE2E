package com.learnautomation.factory;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;

/**
 * DriverFactory.java
 * Manages WebDriver instances using ThreadLocal to support
 * parallel test execution safely.  Each thread gets its own
 * driver instance — no sharing, no race conditions.
 *
 * Usage pattern:
 *   DriverFactory.initDriver("chrome");   // create and store driver
 *   WebDriver driver = DriverFactory.getDriver(); // retrieve
 *   DriverFactory.quitDriver();           // close and remove
 */
public class DriverFactory {

    // Log4j2 logger
    private static final Logger log = LogManager.getLogger(DriverFactory.class);

    /**
     * ThreadLocal container that holds one WebDriver per thread.
     * Initialised to null — populated by initDriver().
     */
    private static final ThreadLocal<WebDriver> driverThreadLocal = new ThreadLocal<>();

    // ----------------------------------------------------------------
    // Initialise driver
    // ----------------------------------------------------------------

    /**
     * Creates a WebDriver for the given browser and stores it in ThreadLocal.
     * Must be called before getDriver() in each test thread.
     *
     * @param browser browser name passed to BrowserFactory
     */
    public static void initDriver(String browser) {
        log.info("Initialising WebDriver — browser: {}, thread: {}",
                 browser, Thread.currentThread().getId());

        WebDriver driver = BrowserFactory.createDriver(browser); // delegate creation
        driverThreadLocal.set(driver);                           // store in ThreadLocal

        log.info("WebDriver stored in ThreadLocal for thread: {}",
                 Thread.currentThread().getId());
    }

    // ----------------------------------------------------------------
    // Retrieve driver
    // ----------------------------------------------------------------

    /**
     * Returns the WebDriver instance for the current thread.
     *
     * @return WebDriver — never null if initDriver() was called first
     * @throws IllegalStateException if driver was not initialised
     */
    public static WebDriver getDriver() {
        WebDriver driver = driverThreadLocal.get(); // fetch from ThreadLocal
        if (driver == null) {
            // Guard: inform developer of incorrect call order
            throw new IllegalStateException(
                "WebDriver not initialised for thread " + Thread.currentThread().getId() +
                ". Call DriverFactory.initDriver(browser) first.");
        }
        return driver;
    }

    // ----------------------------------------------------------------
    // Quit and clean up driver
    // ----------------------------------------------------------------

    /**
     * Quits the WebDriver and removes it from ThreadLocal to prevent memory leaks.
     * Should be called in @AfterMethod or @AfterClass.
     */
    public static void quitDriver() {
        WebDriver driver = driverThreadLocal.get(); // get current thread's driver
        if (driver != null) {
            log.info("Quitting WebDriver for thread: {}", Thread.currentThread().getId());
            driver.quit();                // close all browser windows and kill the process
            driverThreadLocal.remove();   // remove reference to prevent memory leak
            log.info("WebDriver removed from ThreadLocal.");
        } else {
            log.warn("quitDriver() called but no driver found for thread: {}",
                     Thread.currentThread().getId());
        }
    }

    // Private constructor — static utility class
    private DriverFactory() {}
}
