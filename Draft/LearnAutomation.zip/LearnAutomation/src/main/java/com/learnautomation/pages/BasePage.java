package com.learnautomation.pages;

import com.learnautomation.factory.DriverFactory;
import com.learnautomation.utils.WaitUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

/**
 * BasePage.java
 * Abstract parent class for all Page Object classes.
 * Contains reusable low-level Selenium interactions so that each
 * page class focuses on page-specific logic instead of driver boilerplate.
 *
 * All Page Object classes must extend this class.
 */
public abstract class BasePage {

    // Log4j2 logger — available in all subclasses
    protected static final Logger log = LogManager.getLogger(BasePage.class);

    /** WebDriver reference for the current thread */
    protected WebDriver driver;

    // ----------------------------------------------------------------
    // Constructor — initialises PageFactory for @FindBy annotations
    // ----------------------------------------------------------------

    /**
     * Retrieves the thread-local driver and initialises PageFactory.
     * PageFactory links @FindBy annotated fields to actual WebElements.
     */
    public BasePage() {
        this.driver = DriverFactory.getDriver(); // thread-safe driver retrieval
        PageFactory.initElements(driver, this);  // wire up @FindBy annotations
    }

    // ----------------------------------------------------------------
    // Navigation
    // ----------------------------------------------------------------

    /** Navigates to the given URL */
    public void navigateTo(String url) {
        log.info("Navigating to URL: {}", url);
        driver.get(url); // open URL in the browser
    }

    /** Returns the current page title */
    public String getPageTitle() {
        String title = driver.getTitle();
        log.debug("Current page title: {}", title);
        return title;
    }

    /** Returns the current page URL */
    public String getCurrentUrl() {
        return driver.getCurrentUrl();
    }

    // ----------------------------------------------------------------
    // Click
    // ----------------------------------------------------------------

    /**
     * Waits for an element to be clickable, then clicks it.
     *
     * @param locator  By locator of the element
     */
    protected void click(By locator) {
        log.debug("Clicking element: {}", locator);
        WaitUtil.waitForClickability(locator).click(); // wait then click
    }

    /**
     * Clicks a WebElement directly (for @FindBy elements).
     *
     * @param element  WebElement to click
     */
    protected void click(WebElement element) {
        log.debug("Clicking WebElement");
        WaitUtil.waitForClickability(element).click();
    }

    // ----------------------------------------------------------------
    // Type / Send Keys
    // ----------------------------------------------------------------

    /**
     * Clears any existing text in the field, then types the given text.
     *
     * @param locator  By locator of the input field
     * @param text     text to enter
     */
    protected void type(By locator, String text) {
        log.debug("Typing '{}' into element: {}", text, locator);
        WebElement field = WaitUtil.waitForVisibility(locator); // ensure element visible
        field.clear();       // remove any pre-existing text
        field.sendKeys(text); // type new text
    }

    /**
     * Types into a @FindBy WebElement.
     *
     * @param element  input WebElement
     * @param text     text to enter
     */
    protected void type(WebElement element, String text) {
        log.debug("Typing '{}' into WebElement", text);
        WaitUtil.waitForVisibility(element).clear();    // clear first
        element.sendKeys(text);                          // then type
    }

    // ----------------------------------------------------------------
    // Get Text
    // ----------------------------------------------------------------

    /**
     * Returns the visible text of the element.
     *
     * @param locator  By locator
     * @return trimmed text string
     */
    protected String getText(By locator) {
        String text = WaitUtil.waitForVisibility(locator).getText().trim();
        log.debug("Got text '{}' from element: {}", text, locator);
        return text;
    }

    /**
     * Returns the visible text of a @FindBy element.
     *
     * @param element  WebElement
     * @return trimmed text
     */
    protected String getText(WebElement element) {
        return WaitUtil.waitForVisibility(element).getText().trim();
    }

    // ----------------------------------------------------------------
    // Dropdown (HTML <select>)
    // ----------------------------------------------------------------

    /**
     * Selects a dropdown option by its visible text.
     *
     * @param locator      By locator of the <select> element
     * @param visibleText  option label to select
     */
    protected void selectByVisibleText(By locator, String visibleText) {
        log.debug("Selecting '{}' from dropdown: {}", visibleText, locator);
        WebElement dropdown = WaitUtil.waitForVisibility(locator);
        new Select(dropdown).selectByVisibleText(visibleText); // standard HTML select
    }

    /**
     * Selects by visible text from a @FindBy WebElement.
     */
    protected void selectByVisibleText(WebElement element, String visibleText) {
        log.debug("Selecting '{}' from dropdown WebElement", visibleText);
        new Select(element).selectByVisibleText(visibleText);
    }

    // ----------------------------------------------------------------
    // Hover (mouse over)
    // ----------------------------------------------------------------

    /**
     * Moves the mouse over an element (hover) without clicking.
     * Used for revealing dropdown menus.
     *
     * @param element  WebElement to hover over
     */
    protected void hoverOver(WebElement element) {
        log.debug("Hovering over WebElement");
        Actions actions = new Actions(driver);
        actions.moveToElement(element).perform(); // trigger CSS hover state
    }

    /**
     * Hover using By locator.
     *
     * @param locator  By locator of the element to hover
     */
    protected void hoverOver(By locator) {
        log.debug("Hovering over element: {}", locator);
        WebElement element = WaitUtil.waitForVisibility(locator);
        new Actions(driver).moveToElement(element).perform();
    }

    // ----------------------------------------------------------------
    // JavaScript helpers
    // ----------------------------------------------------------------

    /**
     * Scrolls the element into the visible area using JavaScript.
     * Useful when an element is off-screen and can't be interacted with.
     *
     * @param element  WebElement to scroll into view
     */
    protected void scrollIntoView(WebElement element) {
        log.debug("Scrolling element into view");
        ((JavascriptExecutor) driver)
            .executeScript("arguments[0].scrollIntoView(true);", element);
    }

    /**
     * Clicks an element using JavaScript.
     * Fallback when normal click fails due to overlapping elements.
     *
     * @param element  WebElement to click via JS
     */
    protected void jsClick(WebElement element) {
        log.debug("JS click on WebElement");
        ((JavascriptExecutor) driver)
            .executeScript("arguments[0].click();", element);
    }

    // ----------------------------------------------------------------
    // Visibility check
    // ----------------------------------------------------------------

    /**
     * Checks if an element is currently displayed on the page.
     *
     * @param locator  By locator
     * @return true if visible, false otherwise
     */
    protected boolean isDisplayed(By locator) {
        try {
            return driver.findElement(locator).isDisplayed();
        } catch (Exception e) {
            return false; // element not found — treat as not displayed
        }
    }
}
