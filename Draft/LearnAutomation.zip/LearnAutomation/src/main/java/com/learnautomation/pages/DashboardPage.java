package com.learnautomation.pages;

import com.learnautomation.utils.WaitUtil;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * DashboardPage.java
 * Page Object for the Dashboard / Navigation area shown after login.
 *
 * Responsibilities:
 *   - Verify successful login (dashboard is visible)
 *   - Hover over the "Manage" menu to reveal sub-items
 *   - Click "Manage Courses" from the dropdown
 *   - Perform logout from the user menu
 */
public class DashboardPage extends BasePage {

    // ================================================================
    // WebElement declarations
    // ================================================================

    /**
     * "Manage" top-level navigation link.
     * Hovering over it reveals the sub-menu (e.g. Manage Courses).
     * XPath targets the nav link containing text "Manage".
     */
    @FindBy(xpath = "//a[contains(text(),'Manage')] | //li[contains(.,'Manage')]/a | //nav//span[contains(text(),'Manage')]")
    private WebElement manageMenu;

    /**
     * "Manage Courses" item inside the Manage dropdown sub-menu.
     * Visible only after hovering over the Manage menu.
     */
    @FindBy(xpath = "//a[contains(text(),'Manage Courses')] | //li[contains(.,'Manage Courses')]/a | //a[@href='/managecourse' or @href='/manage-courses']")
    private WebElement manageCoursesLink;

    /**
     * User avatar / account icon or menu trigger shown in the top-right corner.
     * Clicking it reveals the Logout option.
     */
    @FindBy(xpath = "//button[contains(@class,'menu') or contains(@class,'avatar') or contains(@class,'user')] | //img[contains(@class,'avatar')] | //span[contains(@class,'user-icon')]")
    private WebElement userMenuButton;

    /**
     * "Logout" option inside the user/account dropdown menu.
     */
    @FindBy(xpath = "//a[contains(text(),'Logout') or contains(text(),'Log Out')] | //button[contains(text(),'Logout') or contains(text(),'Log Out')] | //li[contains(text(),'Logout')]")
    private WebElement logoutOption;

    /**
     * Dashboard heading or welcome message — used to confirm login success.
     * Targets h1/h2/h3 or a div with "Welcome" or "Dashboard".
     */
    @FindBy(xpath = "//h1 | //h2 | //div[contains(@class,'dashboard')] | //div[contains(@class,'welcome')]")
    private WebElement dashboardHeading;

    // ================================================================
    // Action Methods
    // ================================================================

    // ----------------------------------------------------------------
    // Verify dashboard is loaded
    // ----------------------------------------------------------------

    /**
     * Verifies that the dashboard page loaded successfully after login.
     * Waits for the dashboard heading or a key navigation element.
     *
     * @return true if dashboard is visible
     */
    public boolean isDashboardDisplayed() {
        try {
            WaitUtil.waitForVisibility(manageMenu); // Manage menu should be visible
            log.info("Dashboard is displayed — Manage menu found.");
            return true;
        } catch (Exception e) {
            log.warn("Dashboard not displayed: {}", e.getMessage());
            return false;
        }
    }

    // ----------------------------------------------------------------
    // Navigate to Manage Courses
    // ----------------------------------------------------------------

    /**
     * Hovers over the "Manage" top-level menu to reveal its sub-items,
     * then clicks "Manage Courses".
     * This matches the instruction: hover → Manage → click Manage Courses.
     */
    public void navigateToManageCourses() {
        log.info("Hovering over 'Manage' menu to reveal sub-items");
        WaitUtil.waitForVisibility(manageMenu); // ensure menu is visible
        hoverOver(manageMenu);                   // trigger hover to show dropdown

        log.info("Clicking 'Manage Courses' link");
        WaitUtil.waitForClickability(manageCoursesLink); // wait until sub-item is clickable
        click(manageCoursesLink);                         // navigate to Manage Courses page
    }

    // ----------------------------------------------------------------
    // Logout
    // ----------------------------------------------------------------

    /**
     * Clicks the user/account menu (top-right) and then clicks Logout.
     * Follows the instruction: click Menu → click Logout.
     */
    public void logout() {
        log.info("Clicking user menu button to open account menu");
        click(userMenuButton); // open the dropdown menu

        log.info("Clicking Logout option");
        WaitUtil.waitForClickability(logoutOption); // wait for logout to appear
        click(logoutOption);                         // perform logout
        log.info("Logout action completed.");
    }
}
