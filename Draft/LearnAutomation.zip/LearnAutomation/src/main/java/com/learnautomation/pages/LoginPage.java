package com.learnautomation.pages;

import com.learnautomation.utils.WaitUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * LoginPage.java
 * Page Object for the Login page.
 * URL: https://freelance-learn-automation.vercel.app/login
 *
 * Contains:
 *   - @FindBy WebElement declarations (mapped to real UI elements)
 *   - Business-level action methods used by test classes
 *
 * XPaths are derived from inspecting the React application's rendered HTML.
 */
public class LoginPage extends BasePage {

    // ================================================================
    // WebElement declarations using @FindBy
    // ================================================================

    /**
     * Email input field.
     * XPath: input of type "email" inside the login form.
     */
    @FindBy(xpath = "//input[@type='email' or @placeholder='Email' or @name='email']")
    private WebElement emailInput;

    /**
     * Password input field.
     * XPath: input of type "password".
     */
    @FindBy(xpath = "//input[@type='password' or @placeholder='Password' or @name='password']")
    private WebElement passwordInput;

    /**
     * Login / Sign In submit button.
     * XPath: button containing text "Login" or "Sign In".
     */
    @FindBy(xpath = "//button[contains(text(),'Login') or contains(text(),'Sign In') or @type='submit']")
    private WebElement loginButton;

    /**
     * Error message element displayed when credentials are wrong.
     */
    @FindBy(xpath = "//div[contains(@class,'error') or contains(@class,'alert') or contains(@class,'message')]")
    private WebElement errorMessage;

    // ================================================================
    // Action Methods — used directly in test classes
    // ================================================================

    /**
     * Enters the email address into the email input field.
     *
     * @param email  email string to enter
     */
    public void enterEmail(String email) {
        log.info("Entering email: {}", email);
        type(emailInput, email); // inherited from BasePage — clears then types
    }

    /**
     * Enters the password into the password input field.
     *
     * @param password  password string to enter
     */
    public void enterPassword(String password) {
        log.info("Entering password"); // don't log actual password for security
        type(passwordInput, password);
    }

    /**
     * Clicks the Login button to submit the form.
     */
    public void clickLoginButton() {
        log.info("Clicking Login button");
        click(loginButton); // inherited click with explicit wait
    }

    // ----------------------------------------------------------------
    // Combined login action
    // ----------------------------------------------------------------

    /**
     * Performs the complete login flow in one method call.
     * Enters email, enters password, and clicks Login.
     *
     * @param email     user's email
     * @param password  user's password
     */
    public void login(String email, String password) {
        log.info("Performing login with email: {}", email);
        enterEmail(email);       // step 1: enter email
        enterPassword(password); // step 2: enter password
        clickLoginButton();       // step 3: submit
        log.info("Login form submitted.");
    }

    // ----------------------------------------------------------------
    // Verification helpers
    // ----------------------------------------------------------------

    /**
     * Returns the error/validation message text displayed on the login page.
     * Used to verify that invalid login shows an appropriate message.
     *
     * @return visible message text, or empty string if none
     */
    public String getErrorMessage() {
        try {
            WaitUtil.waitForVisibility(errorMessage);
            return getText(errorMessage);
        } catch (Exception e) {
            log.warn("No error message found on login page.");
            return "";
        }
    }

    /**
     * Checks whether the login page is currently displayed.
     * Validates by checking for the presence of the email input field.
     *
     * @return true if email input is visible (login page is shown)
     */
    public boolean isLoginPageDisplayed() {
        return isDisplayed(
            By.xpath("//input[@type='email' or @placeholder='Email' or @name='email']")
        );
    }
}
