package com.learnautomation.pages;

import com.learnautomation.utils.WaitUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

/**
 * ManageCoursesPage.java
 * Page Object for the Manage Courses page.
 * URL reached via: Dashboard → Manage (hover) → Manage Courses
 *
 * Covers:
 *   - Click "Add New Course" button
 *   - Fill course form (name, description, instructor, price, dates, category, file)
 *   - Click Save and verify validation message
 *   - Verify course appears in the list and is Active
 *   - Delete the course and verify deletion
 */
public class ManageCoursesPage extends BasePage {

    // ================================================================
    // WebElement declarations — Add New Course button
    // ================================================================

    /**
     * "Add New Course" button on the Manage Courses listing page.
     * XPath targets a button or link with that text.
     */
    @FindBy(xpath = "//button[contains(text(),'Add New Course') or contains(text(),'Add Course')] | //a[contains(text(),'Add New Course')]")
    private WebElement addNewCourseButton;

    // ================================================================
    // Course Form Fields
    // ================================================================

    /**
     * File upload input (hidden <input type="file">).
     * Use sendKeys() with the file path — DO NOT click the button.
     * XPath targets input[type='file'] inside the form.
     */
    @FindBy(xpath = "//input[@type='file']")
    private WebElement fileInput;

    /**
     * Course Name text input field.
     */
    @FindBy(xpath = "//input[@placeholder='Course Name' or @name='courseName' or @id='courseName'] | //input[contains(@placeholder,'Course') and contains(@placeholder,'Name')]")
    private WebElement courseNameInput;

    /**
     * Course Description textarea or input.
     */
    @FindBy(xpath = "//textarea[@placeholder='Description' or @name='description'] | //input[@placeholder='Description' or @name='description']")
    private WebElement descriptionInput;

    /**
     * Instructor Name input field.
     */
    @FindBy(xpath = "//input[@placeholder='Instructor' or @name='instructor' or @placeholder='Instructor Name']")
    private WebElement instructorInput;

    /**
     * Price input field.
     */
    @FindBy(xpath = "//input[@placeholder='Price' or @name='price' or @type='number']")
    private WebElement priceInput;

    /**
     * Start Date input field (date picker or text input).
     */
    @FindBy(xpath = "//input[@placeholder='Start Date' or @name='startDate' or @id='startDate'] | //input[@type='date'][1]")
    private WebElement startDateInput;

    /**
     * End Date input field.
     */
    @FindBy(xpath = "//input[@placeholder='End Date' or @name='endDate' or @id='endDate'] | //input[@type='date'][2]")
    private WebElement endDateInput;

    /**
     * Category dropdown (<select> or custom dropdown).
     */
    @FindBy(xpath = "//select[@name='category' or @id='category'] | //select[contains(@class,'category')]")
    private WebElement categoryDropdown;

    /**
     * Save button inside the Add Course form.
     */
    @FindBy(xpath = "//button[contains(text(),'Save') or contains(text(),'Submit') or @type='submit']")
    private WebElement saveButton;

    /**
     * Validation / error message shown when form is submitted with empty fields.
     * Example expected text: "Please fill all the fields"
     */
    @FindBy(xpath = "//div[contains(text(),'Please fill') or contains(@class,'error') or contains(@class,'alert') or contains(@class,'validation')] | //p[contains(text(),'Please fill')]  | //span[contains(text(),'Please fill')]")
    private WebElement validationMessage;

    // ================================================================
    // Course List elements (for verification and deletion)
    // ================================================================

    /**
     * Table or list container showing all courses.
     */
    @FindBy(xpath = "//table | //div[contains(@class,'course-list')] | //ul[contains(@class,'courses')]")
    private WebElement coursesTable;

    // ================================================================
    // Action Methods
    // ================================================================

    // ----------------------------------------------------------------
    // Navigate to Add Course form
    // ----------------------------------------------------------------

    /**
     * Clicks the "Add New Course" button to open the course creation form.
     */
    public void clickAddNewCourse() {
        log.info("Clicking 'Add New Course' button");
        WaitUtil.waitForClickability(addNewCourseButton); // ensure button is ready
        click(addNewCourseButton);                         // open the add-course form
    }

    // ----------------------------------------------------------------
    // Form Interactions
    // ----------------------------------------------------------------

    /**
     * Uploads a file by sending the file path directly to the hidden file input.
     * Instruction: "Select any file (Do not click on the button)"
     * Using sendKeys() bypasses the file dialog entirely.
     *
     * @param filePath  absolute path to the file on disk
     */
    public void uploadFile(String filePath) {
        log.info("Uploading file via sendKeys: {}", filePath);
        // Wait for the file input to be present in DOM (it may be hidden — that's fine)
        WaitUtil.waitForPresence(By.xpath("//input[@type='file']"));
        fileInput.sendKeys(filePath); // send file path directly — no dialog needed
        log.info("File path sent to file input element.");
    }

    /**
     * Enters the course name.
     *
     * @param name  course name string
     */
    public void enterCourseName(String name) {
        log.info("Entering course name: {}", name);
        type(courseNameInput, name);
    }

    /**
     * Enters the course description.
     *
     * @param description  description text
     */
    public void enterDescription(String description) {
        log.info("Entering description: {}", description);
        type(descriptionInput, description);
    }

    /**
     * Enters the instructor name.
     *
     * @param instructor  instructor's full name
     */
    public void enterInstructor(String instructor) {
        log.info("Entering instructor name: {}", instructor);
        type(instructorInput, instructor);
    }

    /**
     * Enters the course price.
     *
     * @param price  price as a string (e.g. "500")
     */
    public void enterPrice(String price) {
        log.info("Entering price: {}", price);
        type(priceInput, price);
    }

    /**
     * Sets the start date.
     * For <input type="date"> the format is YYYY-MM-DD.
     * For a text field / date-picker, we send the value directly.
     *
     * @param date  date string in the format accepted by the field
     */
    public void enterStartDate(String date) {
        log.info("Entering start date: {}", date);
        type(startDateInput, date);
    }

    /**
     * Sets the end date.
     *
     * @param date  date string
     */
    public void enterEndDate(String date) {
        log.info("Entering end date: {}", date);
        type(endDateInput, date);
    }

    /**
     * Selects a category from the category dropdown.
     *
     * @param category  visible text of the option to select
     */
    public void selectCategory(String category) {
        log.info("Selecting category: {}", category);
        selectByVisibleText(categoryDropdown, category); // inherited Select helper
    }

    /**
     * Selects the first available category option (useful when the exact value is unknown).
     */
    public void selectFirstCategory() {
        log.info("Selecting first available category");
        // Find the first <option> that is not the placeholder (index 1)
        WaitUtil.waitForVisibility(categoryDropdown);
        org.openqa.selenium.support.ui.Select select =
            new org.openqa.selenium.support.ui.Select(categoryDropdown);
        List<WebElement> options = select.getOptions();
        if (options.size() > 1) {
            select.selectByIndex(1); // index 0 is usually the blank placeholder
            log.info("Selected category: {}", options.get(1).getText());
        }
    }

    // ----------------------------------------------------------------
    // Save / Submit
    // ----------------------------------------------------------------

    /**
     * Clicks the Save button to submit the course form.
     */
    public void clickSave() {
        log.info("Clicking Save button");
        click(saveButton);
    }

    // ----------------------------------------------------------------
    // Validation message
    // ----------------------------------------------------------------

    /**
     * Returns the validation message shown after attempting to save an empty form.
     * Expected: "Please fill all the fields"
     *
     * @return text of the validation message element
     */
    public String getValidationMessage() {
        log.info("Retrieving validation message");
        try {
            WaitUtil.waitForVisibility(validationMessage); // wait for message to appear
            String msg = getText(validationMessage);
            log.info("Validation message: '{}'", msg);
            return msg;
        } catch (Exception e) {
            log.warn("Validation message not found: {}", e.getMessage());
            return "";
        }
    }

    /**
     * Checks if the validation message is displayed.
     *
     * @return true if the element is visible
     */
    public boolean isValidationMessageDisplayed() {
        return isDisplayed(
            By.xpath("//div[contains(text(),'Please fill') or contains(@class,'error')] | //p[contains(text(),'Please fill')] | //span[contains(text(),'Please fill')]")
        );
    }

    // ----------------------------------------------------------------
    // Course list verification
    // ----------------------------------------------------------------

    /**
     * Verifies that a course with the given name appears in the course list.
     * Searches for a table row or list item containing the course name text.
     *
     * @param courseName  name of the course to look for
     * @return true if the course row is found
     */
    public boolean isCoursePresent(String courseName) {
        log.info("Checking if course '{}' is present in the list", courseName);
        try {
            // XPath: find any row / list item that contains the course name text
            By courseRowLocator = By.xpath(
                "//tr[td[contains(text(),'" + courseName + "')]] | " +
                "//div[contains(@class,'course')][contains(.,'" + courseName + "')] | " +
                "//li[contains(.,'" + courseName + "')]"
            );
            WaitUtil.waitForVisibility(courseRowLocator);
            log.info("Course '{}' found in the list.", courseName);
            return true;
        } catch (Exception e) {
            log.warn("Course '{}' NOT found in the list.", courseName);
            return false;
        }
    }

    /**
     * Checks if the course with the given name has "Active" status.
     * Searches within the same row for the word "Active".
     *
     * @param courseName  name of the course to check
     * @return true if the course row shows "Active"
     */
    public boolean isCourseActive(String courseName) {
        log.info("Checking if course '{}' is Active", courseName);
        try {
            By activeLocator = By.xpath(
                "//tr[td[contains(text(),'" + courseName + "')]]//td[contains(text(),'Active')] | " +
                "//tr[td[contains(text(),'" + courseName + "')]]//*[contains(text(),'Active')] | " +
                "//div[contains(.,'" + courseName + "')]//*[contains(text(),'Active')]"
            );
            WaitUtil.waitForVisibility(activeLocator);
            log.info("Course '{}' is Active.", courseName);
            return true;
        } catch (Exception e) {
            log.warn("Active status not found for course '{}'.", courseName);
            return false;
        }
    }

    // ----------------------------------------------------------------
    // Delete course
    // ----------------------------------------------------------------

    /**
     * Clicks the Delete button for the course with the given name.
     * Finds the row containing the course name and clicks its Delete button.
     *
     * @param courseName  name of the course to delete
     */
    public void deleteCourse(String courseName) {
        log.info("Deleting course: '{}'", courseName);

        // XPath: find the Delete button in the same row as the course name
        By deleteButtonLocator = By.xpath(
            "//tr[td[contains(text(),'" + courseName + "')]]//button[contains(text(),'Delete') or contains(@class,'delete')] | " +
            "//tr[td[contains(text(),'" + courseName + "')]]//a[contains(text(),'Delete')] | " +
            "//div[contains(.,'" + courseName + "')]//button[contains(text(),'Delete') or contains(@class,'delete')]"
        );

        WaitUtil.waitForClickability(deleteButtonLocator); // ensure button is ready
        click(deleteButtonLocator);                         // click Delete
        log.info("Delete button clicked for course: '{}'", courseName);

        // Handle confirmation dialog if one appears (alert or modal)
        handleDeleteConfirmation();
    }

    /**
     * Handles any confirmation dialog (JS alert or modal) that appears after Delete.
     * Accepts the confirmation to proceed with deletion.
     */
    private void handleDeleteConfirmation() {
        try {
            // Try to accept a JS alert confirmation box
            org.openqa.selenium.Alert alert = WaitUtil.waitForAlert();
            log.info("Confirmation alert detected: '{}'", alert.getText());
            alert.accept(); // click OK to confirm deletion
            log.info("Deletion confirmed via alert.");
        } catch (Exception e) {
            log.info("No alert found — checking for modal confirm button");
            // If no alert, try clicking a modal "Confirm" or "Yes" button
            try {
                By confirmBtn = By.xpath(
                    "//button[contains(text(),'Confirm') or contains(text(),'Yes') or contains(text(),'OK')]"
                );
                click(confirmBtn);
                log.info("Deletion confirmed via modal button.");
            } catch (Exception ex) {
                log.info("No confirmation dialog found — deletion may complete automatically.");
            }
        }
    }

    /**
     * Verifies that the course has been removed from the list.
     * Waits briefly and then checks that no row with the course name exists.
     *
     * @param courseName  name of the deleted course
     * @return true if the course is NO LONGER in the list (deletion successful)
     */
    public boolean isCourseDeleted(String courseName) {
        log.info("Verifying course '{}' is deleted", courseName);
        WaitUtil.sleep(1500); // brief pause for the UI to refresh after deletion

        By courseRowLocator = By.xpath(
            "//tr[td[contains(text(),'" + courseName + "')]] | " +
            "//div[contains(@class,'course')][contains(.,'" + courseName + "')] | " +
            "//li[contains(.,'" + courseName + "')]"
        );

        boolean stillPresent = isDisplayed(courseRowLocator);
        if (!stillPresent) {
            log.info("Course '{}' successfully deleted from the list.", courseName);
        } else {
            log.warn("Course '{}' still appears in the list after deletion.", courseName);
        }
        return !stillPresent; // return true if NOT present (deleted)
    }
}
