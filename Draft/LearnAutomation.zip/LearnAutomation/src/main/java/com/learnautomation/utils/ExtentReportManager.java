package com.learnautomation.utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.learnautomation.config.Constants;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;

/**
 * ExtentReportManager.java
 * Singleton class that manages the lifecycle of the ExtentReports object.
 * - initReports()  : called once before the entire test suite starts
 * - flushReports() : called once after all tests finish — writes the HTML file
 * - createTest()   : called per test method to create a named test node
 * - getTest()      : retrieves the ExtentTest for the current thread
 */
public class ExtentReportManager {

    // Log4j2 logger
    private static final Logger log = LogManager.getLogger(ExtentReportManager.class);

    /** Single ExtentReports instance shared across all threads */
    private static ExtentReports extent;

    /**
     * ThreadLocal ExtentTest — each thread/test method gets its own node
     * in the report so parallel runs don't mix up log entries.
     */
    private static final ThreadLocal<ExtentTest> testThreadLocal = new ThreadLocal<>();

    // ----------------------------------------------------------------
    // Initialise report — called once in @BeforeSuite
    // ----------------------------------------------------------------

    /**
     * Creates the ExtentSparkReporter (HTML reporter) and attaches it to ExtentReports.
     * Configures report metadata: title, theme, encoding.
     */
    public static synchronized void initReports() {
        if (extent == null) { // guard: initialise only once
            // Ensure the output directory exists
            File reportDir = new File(Constants.REPORT_PATH).getParentFile();
            if (!reportDir.exists()) {
                reportDir.mkdirs(); // create directories if they don't exist
            }

            // SparkReporter generates the modern HTML report
            ExtentSparkReporter sparkReporter = new ExtentSparkReporter(Constants.REPORT_PATH);
            sparkReporter.config().setDocumentTitle("Learn Automation Test Report");  // browser tab title
            sparkReporter.config().setReportName("Course Management Automation Suite"); // report heading
            sparkReporter.config().setTheme(Theme.DARK);          // dark theme — professional look
            sparkReporter.config().setEncoding("utf-8");           // support all characters

            extent = new ExtentReports();                          // create main ExtentReports object
            extent.attachReporter(sparkReporter);                  // attach HTML reporter

            // Add system / environment information shown at top of report
            extent.setSystemInfo("Application URL", Constants.APP_URL);
            extent.setSystemInfo("Tester",          "Mukesh");
            extent.setSystemInfo("Environment",     "Production");
            extent.setSystemInfo("Browser",         Constants.DEFAULT_BROWSER.toUpperCase());
            extent.setSystemInfo("OS",              System.getProperty("os.name"));
            extent.setSystemInfo("Java Version",    System.getProperty("java.version"));

            log.info("ExtentReports initialised. Report path: {}", Constants.REPORT_PATH);
        }
    }

    // ----------------------------------------------------------------
    // Flush — write report to disk — called once in @AfterSuite
    // ----------------------------------------------------------------

    /**
     * Writes all collected test results to the HTML file.
     * Must be called after all tests have run, otherwise the file is empty.
     */
    public static synchronized void flushReports() {
        if (extent != null) {
            extent.flush(); // write to disk
            log.info("ExtentReports flushed to: {}", Constants.REPORT_PATH);
        }
    }

    // ----------------------------------------------------------------
    // Create a test node — called per @Test method
    // ----------------------------------------------------------------

    /**
     * Creates a new test node in the report for the given test name.
     * Stores it in ThreadLocal so parallel tests don't collide.
     *
     * @param testName  display name shown in the report
     * @param description brief description of what the test verifies
     */
    public static synchronized void createTest(String testName, String description) {
        ExtentTest test = extent.createTest(testName, description); // add node to report
        testThreadLocal.set(test);                                  // bind to current thread
        log.info("ExtentTest created: {}", testName);
    }

    // ----------------------------------------------------------------
    // Retrieve current thread's ExtentTest
    // ----------------------------------------------------------------

    /**
     * Returns the ExtentTest bound to the current thread.
     * Use this in test methods and utilities to log steps/pass/fail.
     *
     * @return ExtentTest for current thread
     */
    public static ExtentTest getTest() {
        return testThreadLocal.get();
    }

    // ----------------------------------------------------------------
    // Remove from ThreadLocal after each test
    // ----------------------------------------------------------------

    /** Clears the ThreadLocal reference after a test completes. */
    public static void removeTest() {
        testThreadLocal.remove();
    }

    // Private constructor — static utility class
    private ExtentReportManager() {}
}
