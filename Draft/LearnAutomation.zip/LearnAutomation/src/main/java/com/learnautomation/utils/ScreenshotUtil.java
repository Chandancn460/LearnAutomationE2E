package com.learnautomation.utils;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.learnautomation.config.Constants;
import com.learnautomation.factory.DriverFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * ScreenshotUtil.java
 * Utility class for capturing browser screenshots.
 * Screenshots are:
 *   1. Saved to the screenshots folder on disk.
 *   2. Embedded directly into the ExtentReport HTML via base64.
 */
public class ScreenshotUtil {

    // Log4j2 logger
    private static final Logger log = LogManager.getLogger(ScreenshotUtil.class);

    // Date-time format used in screenshot file names (avoids duplicates)
    private static final SimpleDateFormat DATE_FORMAT =
        new SimpleDateFormat("yyyyMMdd_HHmmss_SSS");

    // ----------------------------------------------------------------
    // Capture screenshot and save to disk
    // ----------------------------------------------------------------

    /**
     * Takes a screenshot of the current browser window and saves it as a PNG file.
     *
     * @param testName  used as part of the file name for easy identification
     * @return absolute path to the saved screenshot file, or null if capture failed
     */
    public static String captureScreenshot(String testName) {
        try {
            WebDriver driver = DriverFactory.getDriver(); // get current driver

            // Cast driver to TakesScreenshot interface
            TakesScreenshot ts = (TakesScreenshot) driver;

            // Capture screenshot as a temporary file
            File srcFile = ts.getScreenshotAs(OutputType.FILE);

            // Build destination file name: testName_timestamp.png
            String timestamp    = DATE_FORMAT.format(new Date());
            String fileName     = testName.replaceAll("\\s+", "_") + "_" + timestamp + ".png";
            String destFilePath = Constants.SCREENSHOT_PATH + fileName;

            // Ensure the screenshots directory exists
            Files.createDirectories(Paths.get(Constants.SCREENSHOT_PATH));

            // Copy the temp file to our screenshots folder
            Files.copy(srcFile.toPath(),
                       Paths.get(destFilePath),
                       StandardCopyOption.REPLACE_EXISTING);

            log.info("Screenshot saved: {}", destFilePath);
            return destFilePath; // return path for report embedding

        } catch (IOException e) {
            log.error("Failed to save screenshot for test '{}': {}", testName, e.getMessage());
            return null;
        }
    }

    // ----------------------------------------------------------------
    // Embed screenshot into ExtentReport
    // ----------------------------------------------------------------

    /**
     * Captures a screenshot and attaches it to the current ExtentTest node.
     * This makes the screenshot visible directly in the HTML report.
     *
     * @param testName  name used in file naming and log messages
     */
    public static void captureAndEmbedScreenshot(String testName) {
        try {
            WebDriver driver = DriverFactory.getDriver();

            // Capture as base64 string — ExtentReports can embed this directly in HTML
            String base64Screenshot =
                ((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64);

            // Also save to disk for reference
            captureScreenshot(testName);

            // Attach to the current test node in the report
            ExtentReportManager.getTest()
                .fail("Screenshot on failure:",
                      MediaEntityBuilder.createScreenCaptureFromBase64String(base64Screenshot)
                                        .build());

            log.info("Screenshot embedded in ExtentReport for test: {}", testName);

        } catch (Exception e) {
            log.error("Could not embed screenshot for '{}': {}", testName, e.getMessage());
        }
    }

    // Private constructor — utility class
    private ScreenshotUtil() {}
}
