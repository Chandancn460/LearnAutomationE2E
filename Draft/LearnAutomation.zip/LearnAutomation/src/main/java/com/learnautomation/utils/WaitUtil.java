package com.learnautomation.utils;

import com.learnautomation.config.Constants;
import com.learnautomation.factory.DriverFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

/**
 * WaitUtil.java
 * Provides reusable explicit-wait helper methods.
 * Explicit waits are preferred over Thread.sleep() because they
 * poll periodically and return as soon as the condition is met,
 * making tests faster and more reliable.
 */
public class WaitUtil {

    // Log4j2 logger
    private static final Logger log = LogManager.getLogger(WaitUtil.class);

    // ----------------------------------------------------------------
    // Helper: create a WebDriverWait with the default timeout
    // ----------------------------------------------------------------

    /**
     * Creates a WebDriverWait for the current thread's driver.
     *
     * @return WebDriverWait configured with EXPLICIT_WAIT_SECONDS
     */
    private static WebDriverWait getWait() {
        WebDriver driver = DriverFactory.getDriver(); // get thread-local driver
        return new WebDriverWait(driver, Duration.ofSeconds(Constants.EXPLICIT_WAIT_SECONDS));
    }

    // ----------------------------------------------------------------
    // Wait for element to be visible
    // ----------------------------------------------------------------

    /**
     * Waits until the element located by the given By is visible on the page.
     *
     * @param locator  By locator for the target element
     * @return the visible WebElement
     */
    public static WebElement waitForVisibility(By locator) {
        log.debug("Waiting for visibility of: {}", locator);
        return getWait().until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    /**
     * Waits until the given WebElement is visible.
     *
     * @param element  WebElement already found
     * @return the visible WebElement
     */
    public static WebElement waitForVisibility(WebElement element) {
        log.debug("Waiting for visibility of WebElement");
        return getWait().until(ExpectedConditions.visibilityOf(element));
    }

    // ----------------------------------------------------------------
    // Wait for element to be clickable
    // ----------------------------------------------------------------

    /**
     * Waits until the element is visible AND enabled so it can be clicked.
     *
     * @param locator  By locator
     * @return the clickable WebElement
     */
    public static WebElement waitForClickability(By locator) {
        log.debug("Waiting for clickability of: {}", locator);
        return getWait().until(ExpectedConditions.elementToBeClickable(locator));
    }

    /**
     * Waits until the given WebElement is clickable.
     *
     * @param element  WebElement
     * @return the clickable WebElement
     */
    public static WebElement waitForClickability(WebElement element) {
        log.debug("Waiting for clickability of WebElement");
        return getWait().until(ExpectedConditions.elementToBeClickable(element));
    }

    // ----------------------------------------------------------------
    // Wait for text to be present
    // ----------------------------------------------------------------

    /**
     * Waits until the given element contains the expected text.
     *
     * @param locator       By locator for the element
     * @param expectedText  text expected to appear in the element
     * @return true if text appears within the timeout
     */
    public static boolean waitForText(By locator, String expectedText) {
        log.debug("Waiting for text '{}' in element: {}", expectedText, locator);
        return getWait().until(
            ExpectedConditions.textToBePresentInElementLocated(locator, expectedText));
    }

    // ----------------------------------------------------------------
    // Wait for element to be present in DOM (not necessarily visible)
    // ----------------------------------------------------------------

    /**
     * Waits until the element is present in the DOM.
     *
     * @param locator  By locator
     * @return the located WebElement
     */
    public static WebElement waitForPresence(By locator) {
        log.debug("Waiting for presence of: {}", locator);
        return getWait().until(ExpectedConditions.presenceOfElementLocated(locator));
    }

    // ----------------------------------------------------------------
    // Wait for alert to be present
    // ----------------------------------------------------------------

    /**
     * Waits until a JavaScript alert is present and returns it.
     *
     * @return the Alert object
     */
    public static org.openqa.selenium.Alert waitForAlert() {
        log.debug("Waiting for alert to appear");
        return getWait().until(ExpectedConditions.alertIsPresent());
    }

    // ----------------------------------------------------------------
    // Static sleep (use sparingly)
    // ----------------------------------------------------------------

    /**
     * Hard sleep — use only when absolutely necessary (e.g. animation delays).
     * Prefer the explicit-wait methods above in most situations.
     *
     * @param millis  milliseconds to sleep
     */
    public static void sleep(long millis) {
        try {
            log.debug("Sleeping for {} ms", millis);
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt(); // restore interrupted status
            log.warn("Sleep interrupted: {}", e.getMessage());
        }
    }

    // Private constructor
    private WaitUtil() {}
}
