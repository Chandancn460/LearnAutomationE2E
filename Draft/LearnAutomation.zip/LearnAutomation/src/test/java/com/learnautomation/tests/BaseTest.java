package com.learnautomation.tests;

import com.aventstack.extentreports.Status;
import com.learnautomation.config.Constants;
import com.learnautomation.config.TestConfig;
import com.learnautomation.factory.DriverFactory;
import com.learnautomation.utils.ExtentReportManager;
import com.learnautomation.utils.ScreenshotUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.ITestResult;
import org.testng.annotations.*;

/**
 * BaseTest.java
 * Parent class for all TestNG test classes.
 * Handles:
 *   - Suite-level report initialisation / teardown (@BeforeSuite / @AfterSuite)
 *   - Browser launch and app navigation (@BeforeMethod)
 *   - Driver teardown and result logging (@AfterMethod)
 *   - Screenshot on failure
 *
 * All test classes extend this class to inherit the lifecycle.
 */
public class BaseTest {

    // Log4j2 logger
    private static final Logger log = LogManager.getLogger(BaseTest.class);

    // Browser name injected from testng.xml — default to "chrome" if not specified
    @Parameters({"browser"})
    protected String browser = Constants.DEFAULT_BROWSER;

    // ================================================================
    // Suite-level lifecycle
    // ================================================================

    /**
     * @BeforeSuite — runs once before all test classes/methods in the suite.
     * Initialises the ExtentReports HTML report.
     */
    @BeforeSuite(alwaysRun = true)
    public void suiteSetup() {
        log.info("===== TEST SUITE STARTING =====");
        ExtentReportManager.initReports(); // create the report object and HTML reporter
        log.info("ExtentReports initialised.");
    }

    /**
     * @AfterSuite — runs once after all tests finish.
     * Flushes the ExtentReport to write the HTML file to disk.
     */
    @AfterSuite(alwaysRun = true)
    public void suiteTeardown() {
        log.info("===== TEST SUITE COMPLETE — flushing report =====");
        ExtentReportManager.flushReports(); // write HTML file to Constants.REPORT_PATH
    }

    // ================================================================
    // Method-level lifecycle
    // ================================================================

    /**
     * @BeforeMethod — runs before each @Test method.
     * 1. Determines the browser (from parameter or system property).
     * 2. Initialises WebDriver via DriverFactory.
     * 3. Navigates to the application URL.
     *
     * @param browserParam  injected from testng.xml <parameter name="browser" ...>
     *                      May be null if not specified; TestConfig handles fallback.
     */
    @BeforeMethod(alwaysRun = true)
    @Parameters({"browser"})
    public void setUp(@Optional("chrome") String browserParam) {
        // Resolve the effective browser from parameter, system property, or default
        String effectiveBrowser = TestConfig.getBrowser(browserParam);
        log.info("=== Setting up test — browser: {} ===", effectiveBrowser);

        DriverFactory.initDriver(effectiveBrowser); // launch browser
        DriverFactory.getDriver().get(TestConfig.getAppUrl()); // navigate to app URL
        log.info("Browser launched and navigated to: {}", TestConfig.getAppUrl());
    }

    /**
     * @AfterMethod — runs after each @Test method, regardless of pass/fail.
     * 1. Logs test result (PASS / FAIL / SKIP) in ExtentReport.
     * 2. Takes screenshot on failure.
     * 3. Quits the driver.
     *
     * @param result  ITestResult injected by TestNG — contains pass/fail info
     */
    @AfterMethod(alwaysRun = true)
    public void tearDown(ITestResult result) {
        String testName = result.getName(); // test method name for logging
        log.info("=== Tearing down test: {} ===", testName);

        // ---- Log test result in ExtentReport ----
        if (result.getStatus() == ITestResult.SUCCESS) {
            // Test passed
            ExtentReportManager.getTest().log(Status.PASS, "Test PASSED: " + testName);
            log.info("Test PASSED: {}", testName);

        } else if (result.getStatus() == ITestResult.FAILURE) {
            // Test failed — log error and capture screenshot
            Throwable cause = result.getThrowable(); // get the failure exception
            ExtentReportManager.getTest()
                .log(Status.FAIL, "Test FAILED: " + testName + " — " + cause.getMessage());
            log.error("Test FAILED: {} — {}", testName, cause.getMessage());

            // Capture screenshot and embed in the report
            ScreenshotUtil.captureAndEmbedScreenshot(testName);

        } else if (result.getStatus() == ITestResult.SKIP) {
            // Test skipped
            ExtentReportManager.getTest().log(Status.SKIP, "Test SKIPPED: " + testName);
            log.warn("Test SKIPPED: {}", testName);
        }

        // ---- Clean up: quit driver and remove ExtentTest from ThreadLocal ----
        DriverFactory.quitDriver();            // close browser
        ExtentReportManager.removeTest();       // clear ThreadLocal to avoid leaks
        log.info("Driver quit and ThreadLocal cleared for test: {}", testName);
    }
}
