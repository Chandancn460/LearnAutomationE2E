package com.learnautomation.tests;

import com.aventstack.extentreports.Status;
import com.learnautomation.config.Constants;
import com.learnautomation.pages.DashboardPage;
import com.learnautomation.pages.LoginPage;
import com.learnautomation.pages.ManageCoursesPage;
import com.learnautomation.utils.ExtentReportManager;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * CourseManagementTest.java
 * Main TestNG test class that covers the end-to-end course management flow:
 *
 *   TC_001 — Verify Login
 *   TC_002 — Verify empty-form validation on Add Course
 *   TC_003 — Add a new course with all details and verify it is active
 *   TC_004 — Delete the added course and verify deletion
 *   TC_005 — Logout
 *
 * Each @Test method:
 *   - Creates an ExtentTest node for reporting
 *   - Logs each step with Status.INFO
 *   - Asserts the expected outcome
 *   - Screenshots on failure are handled in BaseTest.tearDown()
 */
public class CourseManagementTest extends BaseTest {

    // Log4j2 logger
    private static final Logger log = LogManager.getLogger(CourseManagementTest.class);

    // Page Object references — initialised in @BeforeMethod
    private LoginPage        loginPage;
    private DashboardPage    dashboardPage;
    private ManageCoursesPage manageCoursesPage;

    // ================================================================
    // @BeforeMethod — initialise Page Objects before each test
    // ================================================================

    /**
     * Initialises all Page Objects before each test method.
     * Called after BaseTest.setUp() (which launches the browser).
     * Priority=1 ensures this runs AFTER BaseTest's @BeforeMethod (priority=0 default).
     */
    @BeforeMethod(alwaysRun = true, dependsOnMethods = {}) // runs after BaseTest setUp
    public void initPages() {
        loginPage         = new LoginPage();         // Page Object for login page
        dashboardPage     = new DashboardPage();     // Page Object for dashboard
        manageCoursesPage = new ManageCoursesPage(); // Page Object for courses
        log.info("Page Objects initialised.");
    }

    // ================================================================
    // TC_001 — Login Test
    // ================================================================

    /**
     * Test Case: TC_001_VerifyLogin
     * Steps:
     *   1. Navigate to login page (done by BaseTest.setUp).
     *   2. Enter valid email and password.
     *   3. Click Login.
     *   4. Verify dashboard is displayed.
     */
    @Test(priority = 1,
          description = "Verify that admin can log in with valid credentials",
          groups = {"smoke", "regression"})
    public void TC_001_VerifyLogin() {
        // Create test node in ExtentReport
        ExtentReportManager.createTest("TC_001 — Verify Login",
            "Login with valid admin credentials and verify dashboard loads");

        // Step 1: Log info — browser already on login page (BaseTest.setUp navigated there)
        ExtentReportManager.getTest().log(Status.INFO,
            "Navigated to login page: " + Constants.APP_URL);
        log.info("TC_001: Starting login test");

        // Step 2: Enter email
        loginPage.enterEmail(Constants.ADMIN_EMAIL);
        ExtentReportManager.getTest().log(Status.INFO,
            "Entered email: " + Constants.ADMIN_EMAIL);

        // Step 3: Enter password
        loginPage.enterPassword(Constants.ADMIN_PASSWORD);
        ExtentReportManager.getTest().log(Status.INFO, "Entered password");

        // Step 4: Click Login
        loginPage.clickLoginButton();
        ExtentReportManager.getTest().log(Status.INFO, "Clicked Login button");

        // Step 5: Assert dashboard is displayed
        boolean dashboardVisible = dashboardPage.isDashboardDisplayed();
        ExtentReportManager.getTest().log(Status.INFO,
            "Dashboard displayed: " + dashboardVisible);

        Assert.assertTrue(dashboardVisible,
            "Dashboard should be displayed after successful login, but it was not.");

        ExtentReportManager.getTest().log(Status.PASS,
            "TC_001 PASSED: Login successful, dashboard is displayed.");
        log.info("TC_001 PASSED");
    }

    // ================================================================
    // TC_002 — Validate Empty Form on Add Course
    // ================================================================

    /**
     * Test Case: TC_002_VerifyEmptyFormValidation
     * Steps:
     *   1. Login.
     *   2. Navigate to Manage Courses.
     *   3. Click Add New Course.
     *   4. Click Save without entering any data.
     *   5. Verify "Please fill all the fields" message is shown.
     */
    @Test(priority = 2,
          description = "Verify validation message when Save is clicked with empty fields",
          groups = {"regression"})
    public void TC_002_VerifyEmptyFormValidation() {
        ExtentReportManager.createTest("TC_002 — Verify Empty Form Validation",
            "Click Save on empty Add Course form and verify validation message");

        log.info("TC_002: Starting empty form validation test");

        // Step 1: Login
        loginPage.login(Constants.ADMIN_EMAIL, Constants.ADMIN_PASSWORD);
        ExtentReportManager.getTest().log(Status.INFO, "Logged in successfully");

        // Step 2: Navigate to Manage Courses
        dashboardPage.navigateToManageCourses();
        ExtentReportManager.getTest().log(Status.INFO, "Navigated to Manage Courses page");

        // Step 3: Click Add New Course
        manageCoursesPage.clickAddNewCourse();
        ExtentReportManager.getTest().log(Status.INFO, "Clicked 'Add New Course' button");

        // Step 4: Click Save WITHOUT entering any course details
        manageCoursesPage.clickSave();
        ExtentReportManager.getTest().log(Status.INFO,
            "Clicked Save button with all fields empty");

        // Step 5: Get and assert the validation message
        String actualMessage = manageCoursesPage.getValidationMessage();
        ExtentReportManager.getTest().log(Status.INFO,
            "Validation message displayed: '" + actualMessage + "'");

        Assert.assertEquals(actualMessage, Constants.VALIDATION_MSG_EMPTY,
            "Expected validation message '" + Constants.VALIDATION_MSG_EMPTY +
            "' but got: '" + actualMessage + "'");

        ExtentReportManager.getTest().log(Status.PASS,
            "TC_002 PASSED: Validation message '" + actualMessage + "' displayed correctly.");
        log.info("TC_002 PASSED");
    }

    // ================================================================
    // TC_003 — Add New Course and Verify Active Status
    // ================================================================

    /**
     * Test Case: TC_003_AddNewCourse
     * Steps:
     *   1. Login.
     *   2. Navigate to Manage Courses.
     *   3. Click Add New Course.
     *   4. Upload a file using sendKeys (no button click).
     *   5. Fill in: Course Name, Description, Instructor, Price, Start Date, End Date, Category.
     *   6. Click Save.
     *   7. Verify the course appears in the list.
     *   8. Verify the course status is "Active".
     */
    @Test(priority = 3,
          description = "Add a new course with all required details and verify it is active",
          groups = {"smoke", "regression"})
    public void TC_003_AddNewCourse() {
        ExtentReportManager.createTest("TC_003 — Add New Course",
            "Fill all course details, save, and verify course is active in the list");

        log.info("TC_003: Starting Add New Course test");

        // Step 1: Login
        loginPage.login(Constants.ADMIN_EMAIL, Constants.ADMIN_PASSWORD);
        ExtentReportManager.getTest().log(Status.INFO, "Logged in as admin");

        // Step 2: Navigate to Manage Courses
        dashboardPage.navigateToManageCourses();
        ExtentReportManager.getTest().log(Status.INFO, "Navigated to Manage Courses page");

        // Step 3: Click Add New Course
        manageCoursesPage.clickAddNewCourse();
        ExtentReportManager.getTest().log(Status.INFO, "Clicked 'Add New Course' button");

        // Step 4: Upload file using sendKeys (NOT clicking the upload button)
        manageCoursesPage.uploadFile(Constants.SAMPLE_FILE_PATH);
        ExtentReportManager.getTest().log(Status.INFO,
            "File uploaded via sendKeys: " + Constants.SAMPLE_FILE_PATH);

        // Step 5a: Enter Course Name
        manageCoursesPage.enterCourseName(Constants.COURSE_NAME);
        ExtentReportManager.getTest().log(Status.INFO,
            "Course Name entered: " + Constants.COURSE_NAME);

        // Step 5b: Enter Description
        manageCoursesPage.enterDescription(Constants.COURSE_DESCRIPTION);
        ExtentReportManager.getTest().log(Status.INFO,
            "Description entered: " + Constants.COURSE_DESCRIPTION);

        // Step 5c: Enter Instructor Name
        manageCoursesPage.enterInstructor(Constants.INSTRUCTOR_NAME);
        ExtentReportManager.getTest().log(Status.INFO,
            "Instructor entered: " + Constants.INSTRUCTOR_NAME);

        // Step 5d: Enter Price
        manageCoursesPage.enterPrice(Constants.COURSE_PRICE);
        ExtentReportManager.getTest().log(Status.INFO,
            "Price entered: " + Constants.COURSE_PRICE);

        // Step 5e: Enter Start Date (18th April 2025 → 2025-04-18 for date input)
        manageCoursesPage.enterStartDate("2025-04-18");
        ExtentReportManager.getTest().log(Status.INFO,
            "Start Date entered: 2025-04-18 (18th April 2025)");

        // Step 5f: Enter End Date (19th May 2025 → 2025-05-19)
        manageCoursesPage.enterEndDate("2025-05-19");
        ExtentReportManager.getTest().log(Status.INFO,
            "End Date entered: 2025-05-19 (19th May 2025)");

        // Step 5g: Select Category (first available option)
        manageCoursesPage.selectFirstCategory();
        ExtentReportManager.getTest().log(Status.INFO, "Category selected");

        // Step 6: Click Save
        manageCoursesPage.clickSave();
        ExtentReportManager.getTest().log(Status.INFO, "Clicked Save button");

        // Step 7: Verify course appears in the list
        boolean coursePresent = manageCoursesPage.isCoursePresent(Constants.COURSE_NAME);
        ExtentReportManager.getTest().log(Status.INFO,
            "Course present in list: " + coursePresent);

        Assert.assertTrue(coursePresent,
            "Course '" + Constants.COURSE_NAME + "' should appear in the list after saving.");

        // Step 8: Verify course is Active
        boolean courseActive = manageCoursesPage.isCourseActive(Constants.COURSE_NAME);
        ExtentReportManager.getTest().log(Status.INFO,
            "Course active status: " + courseActive);

        Assert.assertTrue(courseActive,
            "Course '" + Constants.COURSE_NAME + "' should have 'Active' status.");

        ExtentReportManager.getTest().log(Status.PASS,
            "TC_003 PASSED: Course added and verified as Active.");
        log.info("TC_003 PASSED");
    }

    // ================================================================
    // TC_004 — Delete Course and Verify Deletion
    // ================================================================

    /**
     * Test Case: TC_004_DeleteCourse
     * Steps:
     *   1. Login.
     *   2. Navigate to Manage Courses.
     *   3. Locate the course added in TC_003.
     *   4. Click Delete.
     *   5. Confirm deletion if prompted.
     *   6. Verify the course is removed from the list.
     */
    @Test(priority = 4,
          description = "Delete the added course and verify it no longer appears in the list",
          groups = {"regression"})
    public void TC_004_DeleteCourse() {
        ExtentReportManager.createTest("TC_004 — Delete Course",
            "Delete the 'My First Course' and verify it is removed from the list");

        log.info("TC_004: Starting Delete Course test");

        // Step 1: Login
        loginPage.login(Constants.ADMIN_EMAIL, Constants.ADMIN_PASSWORD);
        ExtentReportManager.getTest().log(Status.INFO, "Logged in as admin");

        // Step 2: Navigate to Manage Courses
        dashboardPage.navigateToManageCourses();
        ExtentReportManager.getTest().log(Status.INFO, "Navigated to Manage Courses page");

        // Step 3: Verify the course exists before deleting
        boolean courseExists = manageCoursesPage.isCoursePresent(Constants.COURSE_NAME);
        ExtentReportManager.getTest().log(Status.INFO,
            "Course present before deletion: " + courseExists);
        Assert.assertTrue(courseExists,
            "Course '" + Constants.COURSE_NAME + "' should be present before deletion.");

        // Step 4: Click Delete for the course
        manageCoursesPage.deleteCourse(Constants.COURSE_NAME);
        ExtentReportManager.getTest().log(Status.INFO,
            "Delete button clicked for: " + Constants.COURSE_NAME);

        // Step 5 (handled inside deleteCourse): confirmation dialog accepted if present

        // Step 6: Verify the course is gone from the list
        boolean courseDeleted = manageCoursesPage.isCourseDeleted(Constants.COURSE_NAME);
        ExtentReportManager.getTest().log(Status.INFO,
            "Course deleted (not present): " + courseDeleted);

        Assert.assertTrue(courseDeleted,
            "Course '" + Constants.COURSE_NAME + "' should not appear in the list after deletion.");

        ExtentReportManager.getTest().log(Status.PASS,
            "TC_004 PASSED: Course deleted and removed from list.");
        log.info("TC_004 PASSED");
    }

    // ================================================================
    // TC_005 — Logout
    // ================================================================

    /**
     * Test Case: TC_005_Logout
     * Steps:
     *   1. Login.
     *   2. Click the Menu / user icon.
     *   3. Click Logout.
     *   4. Verify login page is shown again.
     */
    @Test(priority = 5,
          description = "Verify admin can logout and is redirected to login page",
          groups = {"smoke", "regression"})
    public void TC_005_Logout() {
        ExtentReportManager.createTest("TC_005 — Logout",
            "Click Logout from menu and verify redirect to login page");

        log.info("TC_005: Starting Logout test");

        // Step 1: Login
        loginPage.login(Constants.ADMIN_EMAIL, Constants.ADMIN_PASSWORD);
        ExtentReportManager.getTest().log(Status.INFO, "Logged in as admin");

        // Step 2 & 3: Click Menu → Logout (both handled in dashboardPage.logout())
        dashboardPage.logout();
        ExtentReportManager.getTest().log(Status.INFO, "Logout performed via user menu");

        // Step 4: Verify login page is displayed again
        boolean loginPageShown = loginPage.isLoginPageDisplayed();
        ExtentReportManager.getTest().log(Status.INFO,
            "Login page displayed after logout: " + loginPageShown);

        Assert.assertTrue(loginPageShown,
            "Login page should be displayed after logout, but it was not.");

        ExtentReportManager.getTest().log(Status.PASS,
            "TC_005 PASSED: Logout successful, login page displayed.");
        log.info("TC_005 PASSED");
    }
}
