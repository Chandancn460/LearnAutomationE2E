package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

/**
 * Page Object for the Manage Courses page (/course/manage).
 *
 * All locators are derived from the SelectorHub screenshot provided.
 */
public class ManageCoursesPage {

    private final WebDriver driver;
    private final WebDriverWait wait;

    // ── Manage Courses page locators ─────────────────────────────
    // "Add Course" button / link
    private static final By ADD_COURSE_BTN     = By.xpath(
            "//button[normalize-space()='Add Course'] | //a[normalize-space()='Add Course']");

    // Course form fields
    private static final By COURSE_NAME_INPUT  = By.xpath(
            "//input[@name='courseName' or @placeholder='Course Name' or @id='courseName']");
    private static final By COURSE_DESC_INPUT  = By.xpath(
            "//textarea[@name='description' or @placeholder='Description'] | " +
            "//input[@name='description' or @placeholder='Description']");
    private static final By CATEGORY_DROPDOWN  = By.xpath(
            "//select[@name='category' or @id='category']");
    private static final By INSTRUCTOR_INPUT   = By.xpath(
            "//input[@name='instructor' or @placeholder='Instructor']");
    private static final By START_DATE_INPUT   = By.xpath(
            "//input[@name='startDate' or @type='date'][1]");
    private static final By END_DATE_INPUT     = By.xpath(
            "//input[@name='endDate' or @type='date'][2]");

    // Submit / Save button inside the form
    private static final By SUBMIT_BTN         = By.xpath(
            "//button[@type='submit'] | //button[normalize-space()='Save'] | " +
            "//button[normalize-space()='Add']");

    // Validation error messages (empty-form submission)
    private static final By VALIDATION_ERRORS  = By.xpath(
            "//*[contains(@class,'error') or contains(@class,'invalid') or " +
            "contains(@class,'validation') or contains(@class,'required')]");

    // Course cards / rows on the listing
    private static final By COURSE_CARDS       = By.xpath(
            "//div[contains(@class,'course-card')] | //div[contains(@class,'courseCard')]");

    // Delete button – relative to a course name
    private static final By DELETE_BTN_XPATH   = By.xpath(
            ".//button[normalize-space()='Delete' or contains(@class,'delete')]");

    // Confirm delete (modal or inline)
    private static final By CONFIRM_DELETE_BTN = By.xpath(
            "//button[normalize-space()='Confirm'] | //button[normalize-space()='Yes'] | " +
            "//button[normalize-space()='OK'] | //button[contains(@class,'confirm')]");

    // ── Constructor ──────────────────────────────────────────────
    public ManageCoursesPage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait   = wait;
    }

    // ── Actions ──────────────────────────────────────────────────

    /** Verify the page heading / URL. Returns true if on Manage Courses page. */
    public boolean isOnManageCoursesPage() {
        return driver.getCurrentUrl().contains("/course/manage");
    }

    /** Click the "Add Course" button to open the course form. */
    public void clickAddCourse() {
        wait.until(ExpectedConditions.elementToBeClickable(ADD_COURSE_BTN)).click();
    }

    /**
     * Submit the Add Course form WITHOUT filling any fields.
     * Used by TC_002 to verify validation messages appear.
     */
    public void submitEmptyForm() {
        clickAddCourse();
        wait.until(ExpectedConditions.elementToBeClickable(SUBMIT_BTN)).click();
    }

    /** Returns true if at least one validation error message is visible. */
    public boolean areValidationErrorsVisible() {
        List<WebElement> errors = driver.findElements(VALIDATION_ERRORS);
        return errors.stream().anyMatch(WebElement::isDisplayed);
    }

    /**
     * Fill and submit the Add Course form with the supplied data.
     */
    public void addCourse(String name, String description, String instructor,
                          String startDate, String endDate) {
        clickAddCourse();

        wait.until(ExpectedConditions.visibilityOfElementLocated(COURSE_NAME_INPUT))
                .sendKeys(name);

        List<WebElement> descField = driver.findElements(COURSE_DESC_INPUT);
        if (!descField.isEmpty()) descField.get(0).sendKeys(description);

        List<WebElement> instrField = driver.findElements(INSTRUCTOR_INPUT);
        if (!instrField.isEmpty()) instrField.get(0).sendKeys(instructor);

        List<WebElement> start = driver.findElements(START_DATE_INPUT);
        if (!start.isEmpty()) start.get(0).sendKeys(startDate);

        List<WebElement> end = driver.findElements(END_DATE_INPUT);
        if (!end.isEmpty()) end.get(0).sendKeys(endDate);

        jsClick(wait.until(ExpectedConditions.elementToBeClickable(SUBMIT_BTN)));
    }

    /**
     * Find the first course card whose title contains {@code courseName}
     * and click its Delete button.
     */
    public void deleteCourseByName(String courseName) {
        // Re-fetch cards every time to avoid stale refs
        List<WebElement> cards = wait.until(
                ExpectedConditions.presenceOfAllElementsLocatedBy(COURSE_CARDS));

        for (WebElement card : cards) {
            if (card.getText().contains(courseName)) {
                WebElement deleteBtn = card.findElement(DELETE_BTN_XPATH);
                jsClick(deleteBtn);

                // Handle confirmation dialog if present
                List<WebElement> confirm = driver.findElements(CONFIRM_DELETE_BTN);
                if (!confirm.isEmpty() && confirm.get(0).isDisplayed()) {
                    confirm.get(0).click();
                }
                return;
            }
        }
        throw new RuntimeException("Course not found on page: " + courseName);
    }

    /** Returns true if no card with the given name is found on the page. */
    public boolean isCourseAbsent(String courseName) {
        List<WebElement> cards = driver.findElements(COURSE_CARDS);
        return cards.stream().noneMatch(c -> c.getText().contains(courseName));
    }

    // ── Internal helpers ─────────────────────────────────────────
    private void jsClick(WebElement el) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", el);
    }
}
