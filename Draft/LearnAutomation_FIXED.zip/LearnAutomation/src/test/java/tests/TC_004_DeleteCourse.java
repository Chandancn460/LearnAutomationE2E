package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.ManageCoursesPage;
import utils.BaseTest;

/**
 * TC_004 – Delete the course that was added by TC_003.
 *
 * FIX APPLIED:
 *  – navigateToManageCourses() uses hover+click pattern matching the real DOM.
 *  – Old XPath that tried direct //a lookups without hover is completely removed.
 *
 * NOTE: This test depends on TC_003 having run first (same session / @BeforeClass
 * is shared via BaseTest).  If you run this standalone, ensure the test course
 * already exists in the app.
 */
public class TC_004_DeleteCourse extends BaseTest {

    private static final String VALID_EMAIL    = "test@gmail.com";
    private static final String VALID_PASSWORD = "Test@1234";

    // Re-use the course name constant from TC_003 so they stay in sync
    private static final String COURSE_TO_DELETE = TC_003_AddNewCourse.TEST_COURSE_NAME;

    @Test(priority = 4, description = "TC_004 – Delete an existing course")
    public void deleteCourse() {

        // Step 1 – Login (safe to call again; BaseTest navigates to /login)
        login(VALID_EMAIL, VALID_PASSWORD);

        // Step 2 – Navigate to Manage Courses (hover + click, KEY FIX)
        navigateToManageCourses();

        Assert.assertTrue(driver.getCurrentUrl().contains("/course/manage"),
                "Did not land on Manage Courses page. URL: " + driver.getCurrentUrl());

        // Step 3 – Delete the target course
        ManageCoursesPage managePage = new ManageCoursesPage(driver, wait);
        managePage.deleteCourseByName(COURSE_TO_DELETE);

        // Step 4 – Give the UI time to refresh, then assert absence
        pause(1500);
        Assert.assertTrue(managePage.isCourseAbsent(COURSE_TO_DELETE),
                "TC_004 FAILED – Course '" + COURSE_TO_DELETE +
                "' still visible after deletion.");

        System.out.println("TC_004 PASSED – Course deleted: " + COURSE_TO_DELETE);
    }
}
