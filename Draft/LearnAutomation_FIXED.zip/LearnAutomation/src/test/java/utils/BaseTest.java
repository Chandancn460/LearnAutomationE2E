package utils;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import java.time.Duration;

public class BaseTest {

    protected WebDriver driver;
    protected WebDriverWait wait;
    protected Actions actions;

    // ── App constants ──────────────────────────────────────────────
    public static final String BASE_URL    = "https://freelance-learn-automation.vercel.app";
    public static final String LOGIN_URL   = BASE_URL + "/login";

    // XPaths confirmed from DevTools / SelectorHub screenshot
    // Navbar – Manage hover trigger
    protected static final By MANAGE_SPAN           = By.xpath("//span[normalize-space()='Manage']");
    // Navbar – Manage Courses link (visible only after hovering Manage)
    protected static final By MANAGE_COURSES_LINK   = By.xpath("//a[normalize-space()='Manage Courses']");
    // Navbar – Manage Categories link
    protected static final By MANAGE_CATEGORIES_LINK = By.xpath("//a[normalize-space()='Manage Categories']");
    // Logout – the nav renders a <a> or <button> with text Logout when signed in
    protected static final By LOGOUT_LINK           = By.xpath(
            "//a[normalize-space()='Logout'] | //button[normalize-space()='Logout']");
    // Login page
    protected static final By EMAIL_FIELD    = By.xpath("//input[@type='email' or @name='email']");
    protected static final By PASSWORD_FIELD = By.xpath("//input[@type='password' or @name='password']");
    protected static final By LOGIN_BTN      = By.xpath(
            "//button[normalize-space()='Login'] | //input[@value='Login']");

    // ── Driver lifecycle ───────────────────────────────────────────
    @BeforeClass
    public void setUp() {
        ChromeOptions options = new ChromeOptions();
        // Remove these two lines if you want a visible browser window during dev
        // options.addArguments("--headless=new");
        options.addArguments("--start-maximized");
        options.addArguments("--disable-notifications");

        driver  = new ChromeDriver(options);
        wait    = new WebDriverWait(driver, Duration.ofSeconds(20));
        actions = new Actions(driver);
        driver.get(BASE_URL);
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    // ── Shared navigation helpers ──────────────────────────────────

    /**
     * Log in with the given credentials.
     * Navigates to the login page if not already there.
     */
    protected void login(String email, String password) {
        driver.get(LOGIN_URL);
        wait.until(ExpectedConditions.visibilityOfElementLocated(EMAIL_FIELD)).clear();
        driver.findElement(EMAIL_FIELD).sendKeys(email);
        driver.findElement(PASSWORD_FIELD).clear();
        driver.findElement(PASSWORD_FIELD).sendKeys(password);
        jsClick(wait.until(ExpectedConditions.elementToBeClickable(LOGIN_BTN)));
        // Wait until URL changes away from login page (auth redirect)
        wait.until(ExpectedConditions.not(
                ExpectedConditions.urlContains("/login")));
    }

    /**
     * KEY FIX: hover over the "Manage" span so the dropdown becomes visible,
     * then click "Manage Courses".
     *
     * Why this was broken before:
     *  – The old code jumped straight to //a[contains(text(),'Manage Courses')]
     *    without first revealing the dropdown via hover.
     *  – The href fallbacks (/managecourse, /manage-courses) don't match the
     *    actual href="/course/manage" shown in the DevTools panel.
     */
    protected void navigateToManageCourses() {
        // Step 1 – hover over the "Manage" trigger span
        WebElement manageSpan = wait.until(
                ExpectedConditions.presenceOfElementLocated(MANAGE_SPAN));
        actions.moveToElement(manageSpan).perform();

        // Step 2 – wait for the dropdown link to become *visible* (not just present)
        WebElement coursesLink = wait.until(
                ExpectedConditions.visibilityOfElementLocated(MANAGE_COURSES_LINK));

        // Step 3 – click; use JS fallback if a stale overlay intercepts
        try {
            actions.moveToElement(coursesLink).click().perform();
        } catch (Exception e) {
            jsClick(coursesLink);
        }

        // Step 4 – confirm navigation landed on the manage courses page
        wait.until(ExpectedConditions.urlContains("/course/manage"));
    }

    /**
     * Logout by clicking the Logout link/button in the navbar.
     * Falls back to JS click if the element is obscured.
     */
    protected void logout() {
        WebElement logoutEl = wait.until(
                ExpectedConditions.elementToBeClickable(LOGOUT_LINK));
        try {
            logoutEl.click();
        } catch (Exception e) {
            jsClick(logoutEl);
        }
        // Confirm we're back on login or home page
        wait.until(ExpectedConditions.or(
                ExpectedConditions.urlContains("/login"),
                ExpectedConditions.urlToBe(BASE_URL + "/"),
                ExpectedConditions.urlToBe(BASE_URL)));
    }

    /**
     * JavaScript click – bypasses overlay / intercepted-click issues.
     */
    protected void jsClick(WebElement element) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
    }

    /**
     * Scroll element into viewport, then JS-click.
     * Useful for buttons near the fold.
     */
    protected void scrollAndClick(WebElement element) {
        ((JavascriptExecutor) driver).executeScript(
                "arguments[0].scrollIntoView({behavior:'smooth',block:'center'});", element);
        pause(300);
        jsClick(element);
    }

    /** Simple pause in ms – use sparingly; prefer explicit waits. */
    protected void pause(int ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }
}
